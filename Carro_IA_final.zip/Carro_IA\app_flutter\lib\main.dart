// App para manejar el carro por Bluetooth clásico (ESP32 + shield L293D),
// con modo Manual, Enseñar y Autónomo (red neuronal en el ESP32).
//
// Letras que entiende carro_ia_esp32.ino:
//   F adelante, B atrás, L izquierda, R derecha, S parar
//   M manual, E enseñar, A autónomo
//   D medir distancia, P imprimir datos, Z borrar datos
//
// Manual:    mantén presionada una flecha para mover el carro; al soltarla
//            se manda S.
// Enseñar:   el carro avanza solo y cuando ve un obstáculo pregunta qué
//            hacer. Toca UNA flecha para responder (no se manda S al soltar,
//            porque en este modo S = freno de emergencia).
// Autónomo:  decide la red neuronal. Las flechas se desactivan.
// El botón rojo siempre para el carro (y en Enseñar/Autónomo vuelve a Manual).
//
// Antes de usarla: empareja "CarroESP32" en los ajustes de Bluetooth de Android.
// En la vista web de FlutLab no hay Bluetooth: corre en "modo demo".

import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_classic_bluetooth/flutter_classic_bluetooth.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const CarroApp());
}

class CarroApp extends StatelessWidget {
  const CarroApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Carro Bluetooth',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: Colors.teal, useMaterial3: true),
      home: const ControlPage(),
    );
  }
}

class ControlPage extends StatefulWidget {
  const ControlPage({super.key});

  @override
  State<ControlPage> createState() => _ControlPageState();
}

class _ControlPageState extends State<ControlPage>
    with WidgetsBindingObserver {
  // En la web no se crea el plugin porque no hay Bluetooth clásico.
  final FlutterClassicBluetooth? _bt =
      kIsWeb ? null : FlutterClassicBluetooth();

  BtcConnection? _conn;
  StreamSubscription<dynamic>? _estadoSub;
  StreamSubscription<dynamic>? _entradaSub;

  bool _conectado = false;
  bool _conectando = false;
  String _nombre = 'Sin conectar';
  String _modo = 'M'; // M manual, E enseñar, A autónomo

  // Lo que va llegando del ESP32, separado por líneas.
  final List<int> _bufferEntrada = [];
  final List<String> _mensajesCarro = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _estadoSub?.cancel();
    _entradaSub?.cancel();
    // dispose() solo libera los streams en Dart: no cierra el socket del
    // celular. Por eso primero se para el carro y se cierra la conexión.
    final conn = _conn;
    _conn = null;
    if (conn != null) unawaited(_cerrarConexion(conn, pararCarro: true));
    super.dispose();
  }

  // Si la app pasa a segundo plano, el carro se detiene por seguridad.
  @override
  void didChangeAppLifecycleState(AppLifecycleState estado) {
    if (estado != AppLifecycleState.resumed) _enviar('S');
  }

  void _mensaje(String texto) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(texto)));
  }

  // Convierte los errores del plugin en mensajes entendibles.
  String _explicar(BtcException e) {
    if (e is BtcPermissionException) {
      return 'Falta el permiso de "Dispositivos cercanos".';
    }
    if (e is BtcDisabledException) {
      return 'El Bluetooth del celular está apagado.';
    }
    if (e is BtcTimeoutException) {
      return 'El carro no respondió. ¿Está prendido y cerca?';
    }
    if (e is BtcConnectionException) {
      return 'No se pudo conectar: ${e.cause.description}';
    }
    return 'Error de Bluetooth: ${e.message}';
  }

  // Pide el permiso de Bluetooth (Android 12+) y revisa que esté prendido.
  Future<bool> _bluetoothListo() async {
    final permiso = await _bt!.requestPermissions();
    if (permiso == BtcPermissionStatus.permanentlyDenied) {
      _mensaje('Activa "Dispositivos cercanos" en los ajustes de la app.');
      await _bt!.openAppSettings();
      return false;
    }
    if (permiso == BtcPermissionStatus.denied) {
      _mensaje('Sin el permiso de Bluetooth no se puede conectar.');
      return false;
    }
    if (!await _bt!.isEnabled()) {
      _mensaje('Prende el Bluetooth del celular y vuelve a intentar.');
      return false;
    }
    return true;
  }

  // Muestra los dispositivos ya emparejados y conecta al que elijas.
  Future<void> _elegirDispositivo() async {
    if (kIsWeb) {
      setState(() {
        _conectado = true;
        _nombre = 'Modo demo (web)';
      });
      return;
    }

    try {
      if (!await _bluetoothListo()) return;

      final lista = await _bt!.getPairedDevices();
      if (!mounted) return;

      final elegido = await showModalBottomSheet<BtcDevice>(
        context: context,
        builder: (ctx) => SafeArea(
          child: lista.isEmpty
              ? const Padding(
                  padding: EdgeInsets.all(24),
                  child: Text(
                    'No hay dispositivos emparejados.\n'
                    'Empareja "CarroESP32" en los ajustes de Bluetooth '
                    'del celular y vuelve a intentar.',
                  ),
                )
              : ListView(
                  shrinkWrap: true,
                  children: [
                    for (final d in lista)
                      ListTile(
                        leading: const Icon(Icons.bluetooth),
                        title: Text(d.displayName),
                        subtitle: Text(d.address),
                        onTap: () => Navigator.pop(ctx, d),
                      ),
                  ],
                ),
        ),
      );

      if (elegido != null) await _conectar(elegido);
    } on BtcException catch (e) {
      _mensaje(_explicar(e));
    }
  }

  Future<void> _conectar(BtcDevice dispositivo) async {
    setState(() => _conectando = true);
    try {
      // Por defecto usa el perfil serie (SPP), el mismo de BluetoothSerial.
      final conn = await _bt!.connect(
        address: dispositivo.address,
        timeout: const Duration(seconds: 10),
      );
      if (!mounted) {
        await _cerrarConexion(conn, pararCarro: false);
        return;
      }

      _conn = conn;
      _estadoSub = conn.stateStream.listen((_) {
        // Si el carro se apaga o se aleja, liberamos la conexión caída.
        if (!conn.isConnected && identical(_conn, conn)) {
          _soltarConexion();
          _mensaje('Se perdió la conexión con el carro.');
        }
      });
      // Lo que manda el ESP32 (distancias, decisiones de la red, etc.).
      _entradaSub = conn.input.listen(_recibir);

      setState(() {
        _conectado = true;
        _nombre = dispositivo.displayName;
        _modo = 'M';
        _mensajesCarro.clear();
        _bufferEntrada.clear();
      });
    } on BtcException catch (e) {
      _mensaje(_explicar(e));
    } finally {
      if (mounted) setState(() => _conectando = false);
    }
  }

  // Junta los bytes que llegan y los separa en líneas de texto.
  void _recibir(List<int> datos) {
    _bufferEntrada.addAll(datos);
    var fin = _bufferEntrada.indexOf(10); // 10 = '\n'
    while (fin >= 0) {
      final linea = utf8
          .decode(_bufferEntrada.sublist(0, fin), allowMalformed: true)
          .trim();
      _bufferEntrada.removeRange(0, fin + 1);
      if (linea.isNotEmpty) _procesarLinea(linea);
      fin = _bufferEntrada.indexOf(10);
    }
  }

  void _procesarLinea(String linea) {
    if (!mounted) return;
    setState(() {
      // El ESP32 avisa cuando cambia de modo; así la app siempre coincide.
      if (linea == 'MODO MANUAL') _modo = 'M';
      if (linea == 'MODO ENSENAR') _modo = 'E';
      if (linea == 'MODO AUTONOMO') _modo = 'A';

      _mensajesCarro.insert(0, linea);
      if (_mensajesCarro.length > 50) _mensajesCarro.removeLast();
    });
  }

  // Cierra el socket y libera la conexión. Si se pide, primero para el carro.
  Future<void> _cerrarConexion(BtcConnection conn,
      {required bool pararCarro}) async {
    try {
      if (pararCarro && conn.isConnected) {
        await conn.output.writeString('S'); // detiene el carro antes de cerrar
      }
      if (conn.isConnected) {
        await conn.finish();
      } else {
        await conn.close();
      }
    } catch (_) {
      // Si la conexión ya estaba caída, no importa.
    }
    conn.dispose();
  }

  // La conexión se cayó sola: cancelamos todo y volvemos a "Sin conectar".
  void _soltarConexion() {
    final conn = _conn;
    _conn = null;
    _estadoSub?.cancel();
    _estadoSub = null;
    _entradaSub?.cancel();
    _entradaSub = null;
    if (conn != null) unawaited(_cerrarConexion(conn, pararCarro: false));
    if (!mounted) return;
    setState(() {
      _conectado = false;
      _nombre = 'Sin conectar';
      _modo = 'M';
    });
  }

  Future<void> _desconectar() async {
    final conn = _conn;
    _conn = null;
    await _estadoSub?.cancel();
    _estadoSub = null;
    await _entradaSub?.cancel();
    _entradaSub = null;

    if (conn != null) await _cerrarConexion(conn, pararCarro: true);

    if (!mounted) return;
    setState(() {
      _conectado = false;
      _nombre = 'Sin conectar';
      _modo = 'M';
    });
  }

  Future<void> _enviar(String comando) async {
    if (kIsWeb) {
      // Modo demo: se simula la respuesta de cambio de modo.
      if (comando == 'S' && _modo != 'M') _procesarLinea('MODO MANUAL');
      if (comando == 'M') _procesarLinea('MODO MANUAL');
      if (comando == 'E') _procesarLinea('MODO ENSENAR');
      if (comando == 'A') _procesarLinea('MODO AUTONOMO');
      return;
    }

    final conn = _conn;
    if (conn == null || !conn.isConnected) return;

    try {
      await conn.output.writeString(comando);
    } on BtcException catch (e) {
      _mensaje('No se pudo enviar: ${_explicar(e)}');
    }
  }

  Future<void> _confirmarBorrado() async {
    final si = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('¿Borrar los datos?'),
        content: const Text(
          'Se borran todas las respuestas guardadas en el ESP32 '
          '(modo Enseñar). No se puede deshacer.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Borrar'),
          ),
        ],
      ),
    );
    if (si == true) _enviar('Z');
  }

  @override
  Widget build(BuildContext context) {
    final esquema = Theme.of(context).colorScheme;

    // Las flechas solo sirven en Manual (mover) y en Enseñar (responder).
    final flechasActivas = _conectado && _modo != 'A';
    final pararAlSoltar = _modo == 'M';

    Widget flecha(IconData icono, String comando) => BotonMando(
          icono: icono,
          comando: comando,
          habilitado: flechasActivas,
          pararAlSoltar: pararAlSoltar,
          onEnviar: _enviar,
        );

    final ayuda = switch (_modo) {
      'E' => 'Enseñar: cuando el carro pregunte, toca una flecha.',
      'A' => 'Autónomo: decide la red neuronal.',
      _ => 'Manual: mantén presionada una flecha.',
    };

    return Scaffold(
      appBar: AppBar(
        title: const Text('Carro Bluetooth'),
        actions: [
          PopupMenuButton<String>(
            enabled: _conectado,
            onSelected: (opcion) {
              if (opcion == 'Z') {
                _confirmarBorrado();
              } else {
                _enviar(opcion);
              }
            },
            itemBuilder: (ctx) => const [
              PopupMenuItem(value: 'D', child: Text('Medir distancia')),
              PopupMenuItem(value: 'P', child: Text('Ver datos guardados')),
              PopupMenuItem(value: 'Z', child: Text('Borrar datos')),
            ],
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            children: [
              Card(
                child: ListTile(
                  leading: Icon(
                    _conectado
                        ? Icons.bluetooth_connected
                        : Icons.bluetooth_disabled,
                    color: _conectado ? esquema.primary : esquema.outline,
                  ),
                  title: Text(_nombre),
                  subtitle: Text(_conectado ? 'Conectado' : 'Desconectado'),
                  trailing: _conectando
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : FilledButton(
                          onPressed:
                              _conectado ? _desconectar : _elegirDispositivo,
                          child: Text(_conectado ? 'Desconectar' : 'Conectar'),
                        ),
                ),
              ),
              const SizedBox(height: 8),
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(
                    value: 'M',
                    label: Text('Manual'),
                    icon: Icon(Icons.gamepad),
                  ),
                  ButtonSegment(
                    value: 'E',
                    label: Text('Enseñar'),
                    icon: Icon(Icons.school),
                  ),
                  ButtonSegment(
                    value: 'A',
                    label: Text('Auto'),
                    icon: Icon(Icons.smart_toy),
                  ),
                ],
                selected: {_modo},
                onSelectionChanged: _conectado
                    ? (seleccion) => _enviar(seleccion.first)
                    : null,
              ),
              const SizedBox(height: 4),
              Text(ayuda, style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 8),
              flecha(Icons.arrow_upward, 'F'),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  flecha(Icons.arrow_back, 'L'),
                  const SizedBox(width: 8),
                  SizedBox(
                    width: 84,
                    height: 84,
                    child: FilledButton(
                      style: FilledButton.styleFrom(
                        backgroundColor: esquema.error,
                        foregroundColor: esquema.onError,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      onPressed: _conectado ? () => _enviar('S') : null,
                      child: const Icon(Icons.stop, size: 44),
                    ),
                  ),
                  const SizedBox(width: 8),
                  flecha(Icons.arrow_forward, 'R'),
                ],
              ),
              const SizedBox(height: 8),
              flecha(Icons.arrow_downward, 'B'),
              const SizedBox(height: 8),
              // Mensajes del carro (el más nuevo arriba).
              Expanded(
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: esquema.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: _mensajesCarro.isEmpty
                      ? Text(
                          'Aquí salen los mensajes del carro.',
                          style: TextStyle(color: esquema.outline),
                        )
                      : ListView.builder(
                          itemCount: _mensajesCarro.length,
                          itemBuilder: (ctx, i) => Text(
                            _mensajesCarro[i],
                            style: TextStyle(
                              fontFamily: 'monospace',
                              fontWeight:
                                  i == 0 ? FontWeight.bold : FontWeight.normal,
                            ),
                          ),
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Botón direccional.
// pararAlSoltar = true (Manual): se mueve mientras lo presionas y al soltar
// manda S. pararAlSoltar = false (Enseñar): solo manda la letra una vez.
class BotonMando extends StatefulWidget {
  const BotonMando({
    super.key,
    required this.icono,
    required this.comando,
    required this.habilitado,
    required this.pararAlSoltar,
    required this.onEnviar,
  });

  final IconData icono;
  final String comando;
  final bool habilitado;
  final bool pararAlSoltar;
  final Future<void> Function(String comando) onEnviar;

  @override
  State<BotonMando> createState() => _BotonMandoState();
}

class _BotonMandoState extends State<BotonMando> {
  bool _presionado = false;

  void _bajar() {
    if (!widget.habilitado) return;
    setState(() => _presionado = true);
    widget.onEnviar(widget.comando);
  }

  void _subir() {
    if (!_presionado) return;
    setState(() => _presionado = false);
    if (widget.pararAlSoltar) widget.onEnviar('S');
  }

  @override
  Widget build(BuildContext context) {
    final esquema = Theme.of(context).colorScheme;

    final fondo = !widget.habilitado
        ? Colors.grey.shade300
        : _presionado
            ? esquema.primary
            : esquema.primaryContainer;
    final colorIcono = !widget.habilitado
        ? Colors.grey.shade500
        : _presionado
            ? esquema.onPrimary
            : esquema.onPrimaryContainer;

    return Listener(
      onPointerDown: (_) => _bajar(),
      onPointerUp: (_) => _subir(),
      onPointerCancel: (_) => _subir(),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        width: 84,
        height: 84,
        decoration: BoxDecoration(
          color: fondo,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Icon(widget.icono, size: 44, color: colorIcono),
      ),
    );
  }
}
