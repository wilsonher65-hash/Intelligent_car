/*
  Carro 2WD con ESP32 + shield L293D + sensor ultrasónico + red neuronal
  ---------------------------------------------------------------------
  Placa:   ESP32 clásico (ESP32 Dev Module / DevKit V1)
  Shield:  motor shield L293D (tipo Adafruit v1, con 74HC595)
  Motores: izquierdo en el borne M1, derecho en el borne M3
  Sensor:  HC-SR04 fijo al frente, alimentado a 3.3 V (TRIG GPIO 25, ECHO GPIO 34, sin resistencias)
  Red:     entrenada en Python (entrenar_red.py). Los pesos están en
           pesos_red.h, que va en esta MISMA carpeta.

  Aparece en el celular como "CarroESP32" (Bluetooth Clásico).

  MODOS
    M  Manual:    lo manejas con las flechas (como antes).
    E  Enseñar:   el carro avanza solo. Cuando ve un obstáculo se detiene,
                  mira a la izquierda, al centro y a la derecha, y te pregunta
                  qué hacer. Tú eliges F, L, R o B en la app. Cada respuesta
                  se guarda en la memoria del ESP32 como ejemplo para la red.
    A  Autónomo:  igual que Enseñar, pero la que decide es la red neuronal.

  COMANDOS (un carácter, por Bluetooth o por el monitor serie a 115200)
    F B L R G I H J   movimientos (en manual)    S  parar
    0..9 velocidad    q  velocidad máxima
    M E A             cambiar de modo (S en Enseñar/Autónomo = parar y volver a manual)
    P  imprimir los datos guardados        Z  borrar los datos guardados
    D  medir la distancia una vez (prueba del sensor)
*/

#include "BluetoothSerial.h"
#include <LittleFS.h>
#include "pesos_red.h"

#if !defined(CONFIG_BT_ENABLED) || !defined(CONFIG_BLUEDROID_ENABLED)
#error "Bluetooth no está habilitado. Usa un ESP32 clásico (ESP32 Dev Module), no un S2, S3 ni C3."
#endif

BluetoothSerial SerialBT;

// ---- Pines: GPIO del ESP32 -> pin del shield (color del cable) ----
const int PIN_CLK    = 17;  // shield 4   CLK del 74HC595     (dorado)
const int PIN_EN     = 4;   // shield 7   EN, activo en LOW   (negro)
const int PIN_SER    = 16;  // shield 8   SER, datos          (naranja)
const int PIN_LATCH  = 18;  // shield 12  LATCH               (rojo)
const int PIN_PWM_M1 = 19;  // shield 11  velocidad M1, izq.  (amarillo)
const int PIN_PWM_M2 = 23;  // shield 6   velocidad M3, der.  (gris)

// ---- Sensor ultrasónico (directo al ESP32, no al shield) ----
const int PIN_TRIG = 25;
const int PIN_ECHO = 34;    // directo: el sensor va a 3.3 V, así el ECHO sale a 3.3 V

const uint8_t M1_A = 3, M1_B = 2;  // motor izquierdo (borne M1), invertido: el frente es el lado del sensor
const uint8_t M2_A = 7, M2_B = 5;  // motor derecho (borne M3), invertido igual

const int PWM_FREQ = 1000;
const int PWM_RES  = 8;

// ---- Ajustes del modo automático (calíbralos probando) ----
const int UMBRAL_CM      = 30;   // si hay algo más cerca, se detiene y mira
const int PELIGRO_CM     = 12;   // más cerca que esto nunca sigue adelante
const int VEL_AUTO       = 180;  // velocidad en Enseñar/Autónomo
const int T_GIRO_MIRAR   = 400;  // ms girando para mirar a cada lado
const int T_GIRO_DECIDIR = 400;  // ms girando cuando elige L o R
const int T_ATRAS        = 500;  // ms en reversa cuando elige B
const int T_AVANCE       = 300;  // ms avanzando cuando elige F
const int T_MEDIA_VUELTA = 1400; // ms girando para dar media vuelta si se atasca
const int MAX_REPETIDAS  = 3;    // misma decisión seguida -> está atascado

const char *ARCHIVO = "/datos.csv";

enum Modo { MANUAL, ENSENAR, AUTONOMO };
Modo modo = MANUAL;

uint8_t registro = 0;
int velocidad = 255;
bool conectado = false;
bool esperandoRespuesta = false;   // en Enseñar: ya miró y espera tu elección
int ultIzq = 0, ultCen = 0, ultDer = 0;
int muestras = 0;
char ultimaAccion = ' ';   // para detectar si repite la misma decisión
int repetidas = 0;

// ===================== PWM (core 2.x y 3.x) =====================
void pwmInit(int pin, int canal) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttach(pin, PWM_FREQ, PWM_RES);
#else
  ledcSetup(canal, PWM_FREQ, PWM_RES);
  ledcAttachPin(pin, canal);
#endif
}

void pwmWrite(int pin, int canal, int valor) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(pin, valor);
#else
  ledcWrite(canal, valor);
#endif
}

// ===================== Motores =====================
void enviarRegistro() {
  digitalWrite(PIN_LATCH, LOW);
  for (int i = 7; i >= 0; i--) {
    digitalWrite(PIN_CLK, LOW);
    digitalWrite(PIN_SER, (registro >> i) & 1);
    digitalWrite(PIN_CLK, HIGH);
  }
  digitalWrite(PIN_LATCH, HIGH);
}

void ponerSentido(uint8_t bitA, uint8_t bitB, int dir) {
  registro &= ~((1 << bitA) | (1 << bitB));
  if (dir == 1)  registro |= (1 << bitA);
  if (dir == -1) registro |= (1 << bitB);
}

void motorIzq(int dir) {
  ponerSentido(M1_A, M1_B, dir);
  enviarRegistro();
  pwmWrite(PIN_PWM_M1, 0, dir == 0 ? 0 : velocidad);
}

void motorDer(int dir) {
  ponerSentido(M2_A, M2_B, dir);
  enviarRegistro();
  pwmWrite(PIN_PWM_M2, 1, dir == 0 ? 0 : velocidad);
}

void adelante()  { motorIzq(1);  motorDer(1);  }
void atras()     { motorIzq(-1); motorDer(-1); }
void izquierda() { motorIzq(-1); motorDer(1);  }
void derecha()   { motorIzq(1);  motorDer(-1); }
void detener()   { motorIzq(0);  motorDer(0);  }

// Escribe en el celular y en el monitor serie a la vez.
void avisar(const String &texto) {
  Serial.println(texto);
  if (SerialBT.hasClient()) SerialBT.println(texto);
}

// ===================== Sensor =====================
// Una medida en cm. Si no vuelve eco (nada al frente), da DIST_MAX.
int medirUnaVez() {
  digitalWrite(PIN_TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(PIN_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(PIN_TRIG, LOW);
  unsigned long us = pulseIn(PIN_ECHO, HIGH, 30000);  // máximo 30 ms (~5 m)
  if (us == 0) return (int)RED_DIST_MAX;
  int cm = us / 58;                                    // ida y vuelta del sonido
  if (cm > RED_DIST_MAX) cm = (int)RED_DIST_MAX;
  return cm;
}

// Tres medidas y se queda con la del medio: quita lecturas locas.
int medir() {
  int a = medirUnaVez(); delay(25);
  int b = medirUnaVez(); delay(25);
  int c = medirUnaVez();
  if (a > b) { int t = a; a = b; b = t; }
  if (b > c) { int t = b; b = c; c = t; }
  if (a > b) { int t = a; a = b; b = t; }
  return b;
}

// ===================== Red neuronal =====================
// Misma cuenta que hace Python: entradas -> capa oculta (tanh) -> salidas.
// Gana la salida con el número más grande.
char decidirRed(int izq, int cen, int der) {
  float x[RED_ENTRADAS] = {
    min(izq, (int)RED_DIST_MAX) / RED_DIST_MAX,
    min(cen, (int)RED_DIST_MAX) / RED_DIST_MAX,
    min(der, (int)RED_DIST_MAX) / RED_DIST_MAX
  };

  float h[RED_OCULTAS];
  for (int j = 0; j < RED_OCULTAS; j++) {
    float s = RED_B1[j];
    for (int i = 0; i < RED_ENTRADAS; i++) s += RED_W1[j][i] * x[i];
    h[j] = tanhf(s);
  }

  int mejor = 0;
  float mejorValor = -1e9;
  for (int k = 0; k < RED_SALIDAS; k++) {
    float s = RED_B2[k];
    for (int j = 0; j < RED_OCULTAS; j++) s += RED_W2[k][j] * h[j];
    if (s > mejorValor) { mejorValor = s; mejor = k; }
  }
  return RED_ACCIONES[mejor];
}

// ===================== Datos guardados =====================
void guardarMuestra(int izq, int cen, int der, char accion) {
  File f = LittleFS.open(ARCHIVO, FILE_APPEND);
  if (!f) { avisar("ERROR: no se pudo guardar"); return; }
  f.printf("%d,%d,%d,%c\n", izq, cen, der, accion);
  f.close();
  muestras++;
  avisar("Guardado #" + String(muestras) + ": " + String(izq) + "," +
         String(cen) + "," + String(der) + " -> " + String(accion));
}

int contarMuestras() {
  File f = LittleFS.open(ARCHIVO, FILE_READ);
  if (!f) return 0;
  int n = 0;
  while (f.available()) if (f.read() == '\n') n++;
  f.close();
  return n;
}

void imprimirDatos() {
  avisar("----- INICIO DATOS (copia desde aqui) -----");
  avisar("izq,cen,der,accion");
  File f = LittleFS.open(ARCHIVO, FILE_READ);
  if (f) {
    while (f.available()) {
      String linea = f.readStringUntil('\n');
      linea.trim();
      if (linea.length() > 0) avisar(linea);
    }
    f.close();
  }
  avisar("----- FIN DATOS (" + String(muestras) + " muestras) -----");
}

// ===================== Comandos =====================
const char *nombreModo() {
  if (modo == ENSENAR) return "ENSENAR";
  if (modo == AUTONOMO) return "AUTONOMO";
  return "MANUAL";
}

void cambiarModo(Modo nuevo) {
  detener();
  modo = nuevo;
  esperandoRespuesta = false;
  if (modo != MANUAL) velocidad = VEL_AUTO;
  avisar(String("MODO ") + nombreModo());
}

bool esDireccion(char c) { return c == 'F' || c == 'L' || c == 'R' || c == 'B'; }

void maniobra(char accion);

void procesar(char c) {
  if (c == '\r' || c == '\n' || c == ' ') return;

  // Comandos que sirven en cualquier modo
  switch (c) {
    case 'M': cambiarModo(MANUAL);   return;
    case 'E': cambiarModo(ENSENAR);  return;
    case 'A': cambiarModo(AUTONOMO); return;
    case 'P': imprimirDatos();       return;
    case 'Z':
      LittleFS.remove(ARCHIVO);
      muestras = 0;
      avisar("Datos borrados");
      return;
    case 'D': avisar("Distancia: " + String(medir()) + " cm"); return;
    case 'q': velocidad = 255; return;
  }
  if (c >= '0' && c <= '9') {
    velocidad = map(c - '0', 0, 9, 120, 255);
    return;
  }

  // En Enseñar/Autónomo, S es el freno de emergencia: para y vuelve a manual.
  if (modo != MANUAL) {
    if (c == 'S') { cambiarModo(MANUAL); return; }
    // En Enseñar, la flecha que mandas es la respuesta a la pregunta.
    if (modo == ENSENAR && esperandoRespuesta && esDireccion(c)) {
      esperandoRespuesta = false;
      guardarMuestra(ultIzq, ultCen, ultDer, c);
      maniobra(c);
    }
    return;  // las demás flechas se ignoran en los modos automáticos
  }

  // Modo manual: igual que el sketch original
  switch (c) {
    case 'F': adelante();  break;
    case 'B': atras();     break;
    case 'L': izquierda(); break;
    case 'R': derecha();   break;
    case 'G': motorIzq(0);  motorDer(1);  break;
    case 'I': motorIzq(1);  motorDer(0);  break;
    case 'H': motorIzq(0);  motorDer(-1); break;
    case 'J': motorIzq(-1); motorDer(0);  break;
    case 'S': detener();   break;
  }
}

// Lee lo que llegue por Bluetooth y por USB.
void leerComandos() {
  while (SerialBT.available()) procesar(SerialBT.read());
  while (Serial.available())   procesar(Serial.read());
}

// Espera "ms" milisegundos sin dejar de escuchar comandos.
// Devuelve false si mientras tanto te saliste del modo (por ejemplo con S).
bool esperar(unsigned long ms) {
  Modo antes = modo;
  unsigned long inicio = millis();
  while (millis() - inicio < ms) {
    leerComandos();
    if (modo != antes) return false;
    delay(5);
  }
  return true;
}

// ===================== Modo automático =====================
// Como el sensor está fijo, el carro gira para mirar a los lados.
bool mirarAlrededor() {
  detener();
  if (!esperar(150)) return false;
  ultCen = medir();

  izquierda();
  if (!esperar(T_GIRO_MIRAR)) return false;
  detener();
  if (!esperar(150)) return false;
  ultIzq = medir();

  derecha();
  if (!esperar(2 * T_GIRO_MIRAR)) return false;
  detener();
  if (!esperar(150)) return false;
  ultDer = medir();

  izquierda();                      // vuelve a mirar al frente
  if (!esperar(T_GIRO_MIRAR)) return false;
  detener();
  return true;
}

void maniobra(char accion) {
  switch (accion) {
    case 'F': adelante();  esperar(T_AVANCE);       break;
    case 'L': izquierda(); esperar(T_GIRO_DECIDIR); break;
    case 'R': derecha();   esperar(T_GIRO_DECIDIR); break;
    case 'B': atras();     esperar(T_ATRAS);        break;
  }
  detener();

  // Después de retroceder, gira hacia el lado más libre. Si no, al volver
  // a mirar ve lo mismo y retrocede otra vez (B, B, B...).
  if (accion == 'B' && modo != MANUAL) {
    if (ultIzq >= ultDer) izquierda(); else derecha();
    esperar(T_GIRO_DECIDIR);
    detener();
  }
}

// Si toma la misma decisión varias veces seguidas, está atascado
// (por ejemplo L, L, L en un rincón). Retrocede y da media vuelta.
bool salirDeAtasco(char accion) {
  if (accion == ultimaAccion) {
    repetidas++;
  } else {
    ultimaAccion = accion;
    repetidas = 1;
  }
  if (repetidas < MAX_REPETIDAS) return false;

  avisar("ATASCADO (" + String(accion) + " x" + String(repetidas) + "): media vuelta");
  atras();
  esperar(T_ATRAS);
  if (ultIzq >= ultDer) izquierda(); else derecha();
  esperar(T_MEDIA_VUELTA);
  detener();
  ultimaAccion = ' ';
  repetidas = 0;
  return true;
}

void pasoAutomatico() {
  if (esperandoRespuesta) return;   // Enseñar: quieto hasta que respondas

  int d = medir();
  if (d > UMBRAL_CM) {              // camino libre
    adelante();
    ultimaAccion = ' ';             // ya salió: se reinicia el contador
    repetidas = 0;
    return;
  }

  if (!mirarAlrededor()) return;    // te saliste del modo mientras miraba
  String lectura = "izq=" + String(ultIzq) + " cen=" + String(ultCen) +
                   " der=" + String(ultDer);

  if (modo == ENSENAR) {
    esperandoRespuesta = true;
    avisar("ELIGE " + lectura + " -> F/L/R/B");
    return;
  }

  // AUTONOMO: decide la red
  char accion = decidirRed(ultIzq, ultCen, ultDer);
  if (accion == 'F' && ultCen < PELIGRO_CM) {
    avisar("IA " + lectura + " -> F (bloqueado por seguridad, uso B)");
    accion = 'B';
  } else {
    avisar("IA " + lectura + " -> " + String(accion));
  }
  if (salirDeAtasco(accion)) return;
  maniobra(accion);
}

// ===================== setup / loop =====================
void setup() {
  pinMode(PIN_CLK, OUTPUT);
  pinMode(PIN_SER, OUTPUT);
  pinMode(PIN_LATCH, OUTPUT);
  pinMode(PIN_EN, OUTPUT);
  digitalWrite(PIN_EN, HIGH);

  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);
  digitalWrite(PIN_TRIG, LOW);

  pwmInit(PIN_PWM_M1, 0);
  pwmInit(PIN_PWM_M2, 1);

  Serial.begin(115200);
  SerialBT.begin("CarroESP32");

  registro = 0;
  enviarRegistro();
  digitalWrite(PIN_EN, LOW);
  detener();

  if (!LittleFS.begin(true)) {      // true = la formatea la primera vez
    Serial.println("ERROR: no arrancó LittleFS (memoria para los datos)");
  }
  muestras = contarMuestras();

  Serial.println("Carro listo. Busca 'CarroESP32' en el Bluetooth del celular.");
  Serial.println("Muestras guardadas: " + String(muestras));
}

void loop() {
  // Si se pierde el celular: para y vuelve a manual (seguridad).
  bool hayCliente = SerialBT.hasClient();
  if (conectado && !hayCliente) {
    modo = MANUAL;
    esperandoRespuesta = false;
    detener();
    Serial.println("Conexión perdida: carro detenido, modo MANUAL");
  }
  conectado = hayCliente;

  leerComandos();

  if (modo != MANUAL) pasoAutomatico();
}
