// Pesos de la red neuronal del carro.
// Generado por entrenar_red.py el 2026-11-19 17:38
// con 95 muestras (precisión en datos de prueba: 68.4 %).
// NO lo edites a mano: vuelve a correr el script.
#pragma once

const int RED_ENTRADAS = 3;   // izquierda, centro, derecha
const int RED_OCULTAS = 8;
const int RED_SALIDAS = 4;
const float RED_DIST_MAX = 200.0f;
const char RED_ACCIONES[RED_SALIDAS] = {'F', 'L', 'R', 'B'};

const float RED_W1[RED_OCULTAS][RED_ENTRADAS] = {
  {2.903661f, 4.964550f, -4.240601f},
  {5.636694f, 2.412711f, 1.153608f},
  {4.189003f, -15.385309f, 3.887476f},
  {0.194605f, 10.328200f, 3.080034f},
  {-11.080370f, 10.290052f, 12.001374f},
  {-6.320007f, 7.660629f, -10.483084f},
  {-13.859775f, -1.400805f, 13.731740f},
  {-18.368198f, -6.055406f, 0.209939f},
};
const float RED_B1[RED_OCULTAS] = {-0.537381f, -2.267142f, 1.553945f, -2.264990f, -1.262599f, 1.057852f, 0.885877f, 1.603077f};

const float RED_W2[RED_SALIDAS][RED_OCULTAS] = {
  {1.951415f, 1.989089f, -4.979383f, 3.158993f, 3.934667f, 3.609705f, -2.198353f, 0.602576f},
  {-0.057811f, 0.089301f, 1.547863f, -1.881410f, -4.142954f, 0.492905f, -2.056750f, -6.963608f},
  {-1.259829f, -0.872353f, 2.978471f, 0.342687f, 1.838001f, -4.625957f, 3.943694f, 6.816458f},
  {-0.171600f, -1.662069f, 0.666769f, -1.432804f, -2.122470f, 0.787632f, 0.753662f, -0.116058f},
};
const float RED_B2[RED_SALIDAS] = {-1.286276f, -0.542634f, -0.688793f, 2.517703f};
