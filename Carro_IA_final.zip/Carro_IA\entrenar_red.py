"""
Entrena la red neuronal del carro y genera pesos_red.h para el ESP32.

No necesita instalar nada: es Python puro (sin numpy ni scikit-learn),
así se ve paso a paso cómo aprende una red neuronal.

Red:  3 entradas (distancia izquierda, centro, derecha)
      -> 8 neuronas ocultas (tanh)
      -> 4 salidas (F adelante, L izquierda, R derecha, B atrás)

Cómo usarlo:
  1. Pega los datos que imprime el carro (comando P) en datos.csv, en esta
     misma carpeta. Puedes pegar todo lo del monitor serie: las líneas que
     no sean datos se ignoran solas.
  2. Ejecuta:   python entrenar_red.py
  3. Se crea carro_ia_esp32/pesos_red.h. Vuelve a subir el sketch al ESP32.

Si no existe datos.csv, usa datos de ejemplo inventados (para probar).
"""

import math
import os
import random
import re
from datetime import datetime

# ---------------- Ajustes ----------------
ACCIONES = ["F", "L", "R", "B"]   # el orden de las salidas (igual en el ESP32)
DIST_MAX = 200.0                  # cm; las distancias se dividen por esto (0 a 1)
OCULTAS = 8                       # neuronas de la capa oculta
EPOCAS = 600                      # vueltas completas a los datos
TASA = 0.1                        # qué tan grandes son los pasos al aprender
SEMILLA = 7                       # para que el resultado se pueda repetir

try:
    CARPETA = os.path.dirname(os.path.abspath(__file__))
except NameError:
    CARPETA = os.getcwd()   # en Colab / Jupyter: la carpeta actual (/content)
ARCHIVO_DATOS = os.path.join(CARPETA, "datos.csv")
ARCHIVO_PESOS = os.path.join(CARPETA, "carro_ia_esp32", "pesos_red.h")

random.seed(SEMILLA)


# ---------------- Datos ----------------
def regla_fija(izq, cen, der):
    """Lo que haría un programa con if, sin red. Sirve para comparar."""
    if izq < 20 and der < 20:
        return "B" if cen < 20 else "F"
    return "L" if izq > der else "R"


def datos_de_ejemplo(n=400):
    """Datos inventados: la regla fija con un 5 % de 'errores humanos'."""
    datos = []
    for _ in range(n):
        izq = random.randint(3, 200)
        cen = random.randint(3, 40)    # el carro solo mira cuando algo está cerca
        der = random.randint(3, 200)
        accion = regla_fija(izq, cen, der)
        if random.random() < 0.05:
            accion = random.choice(ACCIONES)
        datos.append((izq, cen, der, accion))
    return datos


# Una línea de datos es "izq,cen,der,ACCION", por ejemplo "35,12,80,R".
PATRON = re.compile(r"(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*([FLRB])\s*$")


def leer_datos(ruta):
    datos = []
    with open(ruta, encoding="utf-8", errors="ignore") as f:
        for linea in f:
            m = PATRON.search(linea.strip())
            if m:
                izq, cen, der = (int(m.group(i)) for i in (1, 2, 3))
                datos.append((izq, cen, der, m.group(4)))
    return datos


def a_entradas(izq, cen, der):
    """Pasa los cm a números entre 0 y 1 (la red aprende mejor así)."""
    return [min(d, DIST_MAX) / DIST_MAX for d in (izq, cen, der)]


# ---------------- La red ----------------
class Red:
    def __init__(self, entradas, ocultas, salidas):
        def aleatorio(filas, columnas, escala):
            return [[random.uniform(-escala, escala) for _ in range(columnas)]
                    for _ in range(filas)]

        self.W1 = aleatorio(ocultas, entradas, 1.0)   # pesos entrada -> oculta
        self.b1 = [0.0] * ocultas
        self.W2 = aleatorio(salidas, ocultas, 0.5)    # pesos oculta -> salida
        self.b2 = [0.0] * salidas

    def adelante(self, x):
        """Calcula la salida. Es la misma cuenta que hace el ESP32."""
        h = [math.tanh(b + sum(w * xi for w, xi in zip(fila, x)))
             for fila, b in zip(self.W1, self.b1)]
        z = [b + sum(w * hj for w, hj in zip(fila, h))
             for fila, b in zip(self.W2, self.b2)]
        return h, z

    def predecir(self, x):
        _, z = self.adelante(x)
        return z.index(max(z))

    def entrenar_uno(self, x, objetivo, tasa):
        """Un paso de aprendizaje (retropropagación) con un solo ejemplo."""
        h, z = self.adelante(x)

        # Softmax: convierte las salidas en probabilidades.
        mayor = max(z)
        e = [math.exp(v - mayor) for v in z]
        total = sum(e)
        p = [v / total for v in e]
        perdida = -math.log(max(p[objetivo], 1e-12))

        # Error de cada salida: probabilidad - (1 si es la correcta, 0 si no).
        dz = [p[k] - (1.0 if k == objetivo else 0.0) for k in range(len(p))]

        # Error que llega a cada neurona oculta (antes de tocar W2).
        dh = [sum(dz[k] * self.W2[k][j] for k in range(len(dz))) * (1 - h[j] ** 2)
              for j in range(len(h))]

        # Corrige los pesos un poquito en la dirección que baja el error.
        for k in range(len(dz)):
            for j in range(len(h)):
                self.W2[k][j] -= tasa * dz[k] * h[j]
            self.b2[k] -= tasa * dz[k]
        for j in range(len(dh)):
            for i in range(len(x)):
                self.W1[j][i] -= tasa * dh[j] * x[i]
            self.b1[j] -= tasa * dh[j]

        return perdida


def precision(red, datos):
    if not datos:
        return 0.0
    bien = sum(1 for x, y in datos if red.predecir(x) == y)
    return 100.0 * bien / len(datos)


# ---------------- Generar pesos_red.h ----------------
def numeros(lista):
    return ", ".join(f"{v:.6f}f" for v in lista)


def escribir_pesos(red, n_datos, prec_prueba):
    os.makedirs(os.path.dirname(ARCHIVO_PESOS), exist_ok=True)
    acciones_c = ", ".join(f"'{a}'" for a in ACCIONES)
    lineas = [
        "// Pesos de la red neuronal del carro.",
        f"// Generado por entrenar_red.py el {datetime.now():%Y-%m-%d %H:%M}",
        f"// con {n_datos} muestras (precisión en datos de prueba: {prec_prueba:.1f} %).",
        "// NO lo edites a mano: vuelve a correr el script.",
        "#pragma once",
        "",
        "const int RED_ENTRADAS = 3;   // izquierda, centro, derecha",
        f"const int RED_OCULTAS = {OCULTAS};",
        f"const int RED_SALIDAS = {len(ACCIONES)};",
        f"const float RED_DIST_MAX = {DIST_MAX:.1f}f;",
        f"const char RED_ACCIONES[RED_SALIDAS] = {{{acciones_c}}};",
        "",
        "const float RED_W1[RED_OCULTAS][RED_ENTRADAS] = {",
        *[f"  {{{numeros(fila)}}}," for fila in red.W1],
        "};",
        f"const float RED_B1[RED_OCULTAS] = {{{numeros(red.b1)}}};",
        "",
        "const float RED_W2[RED_SALIDAS][RED_OCULTAS] = {",
        *[f"  {{{numeros(fila)}}}," for fila in red.W2],
        "};",
        f"const float RED_B2[RED_SALIDAS] = {{{numeros(red.b2)}}};",
        "",
    ]
    with open(ARCHIVO_PESOS, "w", encoding="utf-8") as f:
        f.write("\n".join(lineas))


# ---------------- Programa principal ----------------
def main():
    if os.path.exists(ARCHIVO_DATOS):
        crudos = leer_datos(ARCHIVO_DATOS)
        print(f"Leí {len(crudos)} muestras de datos.csv")
    else:
        crudos = datos_de_ejemplo()
        print("No encontré datos.csv: uso 400 muestras de EJEMPLO inventadas.")

    if len(crudos) < 20:
        print("Muy pocos datos. Junta al menos 40-50 respuestas en modo Enseñar.")
        return

    conteo = {a: sum(1 for d in crudos if d[3] == a) for a in ACCIONES}
    print("Respuestas por acción:", conteo)
    for a, n in conteo.items():
        if n == 0:
            print(f"  Ojo: no hay ningún ejemplo de '{a}'; la red nunca lo elegirá.")

    # 80 % para entrenar, 20 % para probar con datos que la red NO vio.
    random.shuffle(crudos)
    corte = int(len(crudos) * 0.8)
    convertir = lambda d: (a_entradas(*d[:3]), ACCIONES.index(d[3]))
    entrenamiento = [convertir(d) for d in crudos[:corte]]
    prueba = [convertir(d) for d in crudos[corte:]]

    red = Red(3, OCULTAS, len(ACCIONES))
    print(f"\nEntrenando {EPOCAS} épocas con {len(entrenamiento)} muestras...")
    for epoca in range(1, EPOCAS + 1):
        random.shuffle(entrenamiento)
        perdida = sum(red.entrenar_uno(x, y, TASA) for x, y in entrenamiento)
        if epoca % 100 == 0 or epoca == 1:
            print(f"  época {epoca:4d}   error medio {perdida / len(entrenamiento):.3f}"
                  f"   acierta {precision(red, entrenamiento):5.1f} %")

    prec_ent = precision(red, entrenamiento)
    prec_prueba = precision(red, prueba)
    reglas = crudos[corte:]
    prec_regla = (100.0 * sum(1 for d in reglas if regla_fija(*d[:3]) == d[3])
                  / len(reglas)) if reglas else 0.0

    print("\nRESULTADOS")
    print(f"  Red, datos de entrenamiento: {prec_ent:5.1f} %")
    print(f"  Red, datos de prueba:        {prec_prueba:5.1f} %   <- la que importa")
    print(f"  Reglas fijas (if), prueba:   {prec_regla:5.1f} %   (para comparar)")

    # Tabla: filas = lo que hiciste tú, columnas = lo que dijo la red.
    print("\n  Tú \\ Red   " + "   ".join(ACCIONES))
    for i, a in enumerate(ACCIONES):
        fila = [sum(1 for x, y in prueba if y == i and red.predecir(x) == k)
                for k in range(len(ACCIONES))]
        print(f"      {a}      " + "  ".join(f"{n:2d}" for n in fila))

    print("\nEjemplos de decisiones:")
    for izq, cen, der in [(150, 15, 20), (20, 15, 150), (10, 8, 12), (15, 35, 12)]:
        accion = ACCIONES[red.predecir(a_entradas(izq, cen, der))]
        print(f"  izq={izq:3d} cen={cen:3d} der={der:3d} -> {accion}")

    escribir_pesos(red, len(crudos), prec_prueba)
    print(f"\nListo: {ARCHIVO_PESOS}")
    print("Vuelve a subir carro_ia_esp32.ino al ESP32 para usar los pesos nuevos.")


if __name__ == "__main__":
    main()
