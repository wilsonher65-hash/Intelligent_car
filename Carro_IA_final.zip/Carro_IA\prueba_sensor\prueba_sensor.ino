/*
  Prueba del sensor ultrasónico HC-SR04 con el ESP32 (alimentado a 3.3 V)

  Conexión:
    VCC  -> 3V3 del ESP32
    GND  -> GND del ESP32
    TRIG -> GPIO 25
    ECHO -> GPIO 34 (directo, porque el sensor está a 3.3 V)

  Abre el monitor serie a 115200 y pon algo frente al sensor.
*/

const int PIN_TRIG = 25;
const int PIN_ECHO = 34;

int lecturasMalas = 0;   // veces seguidas sin eco
int total = 0;
int buenas = 0;

void setup() {
  Serial.begin(115200);
  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);
  digitalWrite(PIN_TRIG, LOW);
  delay(500);
  Serial.println();
  Serial.println("=== Prueba del HC-SR04 a 3.3 V ===");
  Serial.println("Pon una pared o tu mano a 20, 50 y 100 cm y compara.");
}

void loop() {
  // Pulso de 10 microsegundos en TRIG = "dispara el sonido"
  digitalWrite(PIN_TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(PIN_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(PIN_TRIG, LOW);

  // ECHO queda en HIGH el tiempo que tarda el sonido en ir y volver
  unsigned long us = pulseIn(PIN_ECHO, HIGH, 30000);
  total++;

  if (us == 0) {
    lecturasMalas++;
    Serial.println("Sin eco (nada al frente o le falta voltaje)");
  } else {
    lecturasMalas = 0;
    buenas++;
    float cm = us / 58.0;
    Serial.print("Distancia: ");
    Serial.print(cm, 1);
    Serial.println(" cm");
  }

  // Cada 20 lecturas, un resumen
  if (total % 20 == 0) {
    Serial.print("--- Resumen: ");
    Serial.print(buenas);
    Serial.print(" de 20 lecturas con eco");
    if (buenas >= 18) Serial.println(" -> el sensor responde bien");
    else if (buenas >= 10) Serial.println(" -> responde a medias (revisa cables o prueba a 5V)");
    else Serial.println(" -> casi no responde: con 3.3 V no le alcanza, toca 5V");
    buenas = 0;
  }

  delay(500);
}
